//"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
//" Script Title       : 
//"                      
//" Script Date        : Sun Sep 13 21:48:21 2020
//"                       
//"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

function Action()
{
	web.url(
		{
			name : 'dd.xml', 
			url : 'http://192.168.0.22:37616/dd.xml', 
			resource : 1, 
			recContentType : 'application/xml', 
			referer : '', 
			snapshot : 't20.inf'
		}
	);

	web.url(
		{
			name : 'device-desc.xml', 
			url : 'http://192.168.0.38:8008/ssdp/device-desc.xml', 
			resource : 1, 
			recContentType : 'application/xml', 
			referer : '', 
			snapshot : 't21.inf'
		}
	);

	web.url(
		{
			name : 'dd.xml_2', 
			url : 'http://192.168.0.43:8060/dial/dd.xml', 
			resource : 0, 
			recContentType : 'text/xml', 
			referer : '', 
			snapshot : 't22.inf', 
			mode : 'HTML'
		}
	);

	return 0;
}

